# メッセージを表示

# 英語のメッセージを表示
print("Hello, Python world")
# 日本語のメッセージを表示
print("Pythonを勉強しましょう")