#足し算

print("足し算")
a = 10
b = 20
c = a + b
print("a=",a)
print("b=",b)
print("c=a+b=",c)
