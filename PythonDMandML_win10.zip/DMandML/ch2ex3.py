# if文

a = input("キーボードから入力してください。a=")
a = int(a)
if a % 2 == 0:
    print("a=",a,"は偶数です。")
else:
    print("a=",a,"は奇数です。")
