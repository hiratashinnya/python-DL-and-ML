#　for文
#  整数を表示する

for m in range(21):
    print(m)
    