#　for文
#  ｎまでの整数の総和を求める

n = 20
s = 0
for m in range(1,n+1):
    s = s + m
    print("m=",m,"\t s=",s)
    