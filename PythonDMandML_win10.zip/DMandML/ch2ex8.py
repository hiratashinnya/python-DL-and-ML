# while文

m = 0
while m < 20:
    m += 1
    print("m=",m)
    